package interfaces;

public interface SayByeObjectInterface {
	public String sayBye(String name);
}
