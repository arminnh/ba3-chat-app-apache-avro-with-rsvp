package interfaces;

public interface SayHelloObjectInterface {
	public String sayHello(String name);
	public Integer add(Integer a, Integer b);
}

