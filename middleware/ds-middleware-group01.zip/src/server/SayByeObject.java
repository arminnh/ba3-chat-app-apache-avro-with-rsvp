package server;

public class SayByeObject implements interfaces.SayByeObjectInterface {
	public String sayBye(String name) {
		return "Bye, " + name;
	}

}
